class imageLink {
  static const String onboarding1 = 'assets/images/onBoarding1.svg';
  static const String onboarding2 = 'assets/images/onBoarding2.svg';
  static const String onboarding3 = 'assets/images/onBoarding3.svg';
  static const String logo = 'assets/images/logo.svg';
  static const String email_icon = 'assets/images/email_icon.svg';
  static const String facebook_icon = 'assets/images/facebook_icon.svg';
  static const String google_icon = 'assets/images/google_icon.svg';
  static const String password_icon = 'assets/images/password_icon.svg';
  static const String person_icon = 'assets/images/person_icon.svg';
}
