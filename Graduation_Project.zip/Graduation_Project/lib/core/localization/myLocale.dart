import 'package:get/get.dart';

class MyTranslation extends Translations {
  Map<String, Map<String, String>> get keys => {
        "en": {
          /// On boarding Pages
          '1': 'Choose Product',
          '2':
              'A product is the item offered for sale A product can be a service or an item. It can be physical or in virtual or cyber form',
          '3': 'Make Payment',
          '4':
              'Payment is the transfer of money services in exchange product or Payments typically made terms agreed',
          '5': 'Get Your Order',
          '6':
              'Business or commerce an order is a stated intention either spoken to engage in a commercial transaction specific products',
          '7': 'Skip',
          '8': 'Get Started',
          '9': 'Next',

          /////////////////////////////////////////////////////////////////////////
          ///
        }
      };
}
